export class Histograms {
  private values = new Map<string, number[]>();
  observe(name: string, ms: number) {
    if (!Number.isFinite(ms) || ms < 0) return;
    const list = this.values.get(name) ?? [];
    list.push(ms);
    if (list.length > 10000) list.shift();
    this.values.set(name, list);
  }
  snapshot() {
    return Object.fromEntries(
      [...this.values].map(([name, v]) => {
        const a = [...v].sort((a, b) => a - b);
        return [
          name,
          {
            count: a.length,
            p50: a[Math.floor((a.length - 1) * 0.5)],
            p95: a[Math.floor((a.length - 1) * 0.95)],
            p99: a[Math.floor((a.length - 1) * 0.99)],
            max: a.at(-1),
          },
        ];
      }),
    );
  }
}
export async function notify(message: string) {
  const token = process.env.TELEGRAM_BOT_TOKEN,
    chat = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chat) return;
  const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ chat_id: chat, text: message.slice(0, 1000) }),
    signal: AbortSignal.timeout(5000),
  });
  if (!res.ok) throw Error("Telegram notification failed");
}
