import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { StateSchema, type State, type Strategy } from "./model.js";
export function initial(strategy: Strategy, balanceSol = 10): State {
  return {
    version: 1,
    mode: "paper",
    running: false,
    killed: false,
    balanceSol,
    day: new Date().toISOString().slice(0, 10),
    dailySpendSol: 0,
    failures: 0,
    strategies: [strategy],
    launches: [],
    positions: [],
    trades: [],
    alerts: [],
    seen: [],
    pendingLaunches: [],
    metrics: {},
    rpc: { status: "not-configured" },
    realizedPnlSol: 0,
  };
}
export class Store {
  private tail: Promise<unknown> = Promise.resolve();
  constructor(
    public state: State,
    private path?: string,
  ) {}
  async transaction<T>(fn: (s: State) => T | Promise<T>): Promise<T> {
    const op = this.tail.then(async () => {
      const next = structuredClone(this.state);
      const result = await fn(next);
      StateSchema.parse(next);
      if (this.path) {
        await mkdir(dirname(this.path), { recursive: true });
        await writeFile(this.path + ".tmp", JSON.stringify(next), {
          mode: 0o600,
        });
        await rename(this.path + ".tmp", this.path);
      }
      this.state = next;
      return result;
    });
    this.tail = op.catch(() => {});
    return op;
  }
}
export async function load(path: string, fallback: State) {
  try {
    const s = StateSchema.parse(JSON.parse(await readFile(path, "utf8")));
    s.running = false;
    s.pendingLaunches = [];
    return new Store(s, path);
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === "ENOENT")
      return new Store(fallback, path);
    throw e;
  }
}
