import Fastify from "fastify";
import { readFile, access, readdir } from "node:fs/promises";
import { resolve, extname } from "node:path";
import { z } from "zod";
import { StrategySchema } from "./model.js";
import { initial, load } from "./store.js";
import { Engine, alert, syntheticLaunch } from "./engine.js";
import { authorized } from "./wallet.js";
import { Histograms, notify } from "./telemetry.js";
import { Pool } from "pg";
import { Connection } from "@solana/web3.js";
import {
  SolanaMonitor,
  VERIFIED_PROGRAMS,
  decodeLaunch,
  scanMint,
  inspectTransaction,
  type PumpLaunch,
} from "./chain.js";
import { appendFile, mkdir } from "node:fs/promises";
const token = process.env.API_TOKEN ?? "";
if (token.length < 32)
  throw Error("Set API_TOKEN to at least 32 random characters");
if ((process.env.MODE ?? "paper") !== "paper")
  throw Error(
    "Live mode unavailable: audited protocol adapters and signer authorization required",
  );
const strategy = StrategySchema.parse(
  JSON.parse(await readFile(resolve("config/strategy.json"), "utf8")),
);
const balance = Number(process.env.INITIAL_BALANCE_SOL ?? 10);
if (!Number.isFinite(balance) || balance <= 0)
  throw Error("Invalid initial balance");
const store = await load(
  process.env.STATE_PATH ?? "data/state.json",
  initial(strategy, balance),
);
const engine = new Engine(store);
const metrics = new Histograms();
const db = process.env.DATABASE_URL
  ? new Pool({ connectionString: process.env.DATABASE_URL })
  : undefined;
const connection = process.env.SOLANA_RPC_URL
  ? new Connection(process.env.SOLANA_RPC_URL, "confirmed")
  : undefined;
const discoveries: PumpLaunch[] = [];
let monitor: SolanaMonitor | undefined;
let observationQueue = Promise.resolve();
let pendingObservations = 0;
const app = Fastify({
  logger: { redact: ["req.headers.authorization", "req.headers.cookie"] },
  bodyLimit: 32768,
});
let replaySequence = Math.max(
  0,
  ...store.state.seen
    .filter((id) => /^synthetic-\d+$/.test(id))
    .map((id) => Number(id.slice(10))),
);
app.addHook("onSend", async (_req, reply, payload) => {
  reply
    .header("x-content-type-options", "nosniff")
    .header("x-frame-options", "DENY")
    .header("referrer-policy", "no-referrer")
    .header(
      "content-security-policy",
      "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
    );
  return payload;
});
app.addHook("onRequest", async (req, reply) => {
  if (!req.routeOptions.url?.startsWith("/api/")) return;
  reply.header("cache-control", "no-store");
  if (!authorized(req.headers.authorization, token))
    return reply.code(401).send({ error: "Unauthorized" });
  const origin = req.headers.origin;
  if (origin) {
    try {
      if (new URL(origin).host !== req.headers.host)
        return reply.code(403).send({ error: "Origin rejected" });
    } catch {
      return reply.code(403).send({ error: "Origin rejected" });
    }
  }
});
app.setErrorHandler((err, req, reply) => {
  req.log.warn(
    { message: err instanceof Error ? err.message : "Request failed" },
    "request rejected",
  );
  reply
    .code(400)
    .send({ error: err instanceof Error ? err.message : "Request failed" });
});
app.get("/health", async () => ({ ok: true, mode: "paper" }));
app.get("/api/state", async () => ({
  ...store.state,
  latencies: metrics.snapshot(),
  discoveries,
}));
app.get("/api/chain/mints/:mint", async (req) => {
  if (!connection) throw Error("Read-only RPC not configured");
  const { mint } = req.params as {
    mint: string;
  };
  return scanMint(connection, mint);
});
app.get("/api/chain/transactions/:signature", async (req) => {
  if (!connection) throw Error("Read-only RPC not configured");
  const { signature } = req.params as {
    signature: string;
  };
  return inspectTransaction(connection, signature);
});
app.post("/api/control", async (req) => {
  const { action } = z
    .object({ action: z.enum(["start", "stop", "kill", "reset"]) })
    .strict()
    .parse(req.body);
  return store.transaction((s) => {
    if (action === "reset") {
      if (s.running) throw Error("Stop before resetting circuit breaker");
      s.killed = false;
      s.failures = 0;
    } else if (action === "kill") {
      s.pendingLaunches = [];
      s.killed = true;
      s.running = false;
    } else if (action === "start") {
      if (s.killed) throw Error("Reset kill switch first");
      if (s.failures >= s.strategies[0].maxFailures)
        throw Error("Failure circuit breaker active");
      s.running = true;
    } else {
      s.running = false;
      s.pendingLaunches = [];
    }
    alert(s, `Operator ${action}; paper mode`);
    return { running: s.running, killed: s.killed };
  });
});
app.post("/api/strategies", async (req) => {
  const c = StrategySchema.parse(req.body);
  return store.transaction((s) => {
    if (s.running) throw Error("Stop trading before changing settings");
    s.strategies = [c];
    return c;
  });
});
app.post("/api/replay", async () => {
  const begin = performance.now();
  const launch = syntheticLaunch(++replaySequence);
  const result = await engine.ingest(launch);
  metrics.observe("synthetic_event_to_decision_ms", performance.now() - begin);
  let auditPersisted = true;
  if (db) {
    try {
      await db.query(
        "INSERT INTO events (id, kind, payload) VALUES ($1,$2,$3) ON CONFLICT (id) DO NOTHING",
        [launch.id, "synthetic-launch", launch],
      );
    } catch {
      auditPersisted = false;
      app.log.error(
        "PostgreSQL event audit failed; local paper result committed",
      );
    }
  }
  return { ...result, auditPersisted };
});
app.post("/api/positions/:id/exit", async (req) => {
  const { id } = req.params as {
    id: string;
  };
  const { fraction } = z
    .object({ fraction: z.number().positive().max(1).default(1) })
    .strict()
    .parse(req.body ?? {});
  return engine.sell(id, fraction);
});
app.post("/api/paper/mark", async (req) => {
  const v = z
    .object({
      mint: z.string(),
      priceSol: z.number().positive(),
      liquiditySol: z.number().nonnegative(),
    })
    .strict()
    .parse(req.body);
  if (
    !store.state.positions.some(
      (p) => p.mint === v.mint && p.source === "synthetic",
    )
  )
    throw Error("Manual marks limited to synthetic fixtures");
  await engine.mark(v.mint, v.priceSol, v.liquiditySol);
  return { ok: true };
});
const publicRoot = resolve("frontend/dist");
try {
  await access(publicRoot);
  const types: Record<string, string> = {
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".ico": "image/x-icon",
    ".woff2": "font/woff2",
  };
  // Register only build files discovered at startup, never translate an incoming path to a filesystem path.
  for (const file of await readdir(publicRoot, { recursive: true })) {
    const type = types[extname(file)];
    if (!type || file.split("/").some((part) => part.startsWith("."))) continue;
    const bytes = await readFile(resolve(publicRoot, file));
    app.get("/" + file, async (_req, reply) => reply.type(type).send(bytes));
  }
  const index = await readFile(resolve(publicRoot, "index.html"));
  app.get("/", async (_req, reply) =>
    reply.type("text/html; charset=utf-8").send(index),
  );
  app.setNotFoundHandler(async (req, reply) =>
    req.url.startsWith("/api/")
      ? reply.code(404).send({ error: "Not found" })
      : reply.type("text/html; charset=utf-8").send(index),
  );
} catch (error) {
  app.log.info("Frontend build missing; run npm --prefix frontend run build");
}
let ticking = false;
const strategyTimer = setInterval(async () => {
  if (ticking) return;
  ticking = true;
  try {
    await engine.tick();
  } catch {
    app.log.warn("Paper timer failed; inspect current evidence and state");
  } finally {
    ticking = false;
  }
}, 1000);
strategyTimer.unref();
// Send only server-generated, non-sensitive alert messages. Serial delivery, bounded backlog.
let notified = store.state.alerts[0]?.id;
let sending = false;
const timer = setInterval(async () => {
  if (sending) return;
  sending = true;
  try {
    const alerts = store.state.alerts;
    const end = notified ? alerts.findIndex((a) => a.id === notified) : -1;
    const pending = (
      end < 0 ? alerts.slice(0, 5) : alerts.slice(0, end)
    ).reverse();
    for (const a of pending) await notify(`[PAPER] ${a.message}`);
    notified = alerts[0]?.id;
  } catch {
    app.log.warn("Notification delivery failed");
  } finally {
    sending = false;
  }
}, 5000);
timer.unref();
const close = async () => {
  clearInterval(timer);
  clearInterval(strategyTimer);
  monitor?.stop();
  await observationQueue;
  await app.close();
  await db?.end();
  process.exit(0);
};
process.once("SIGINT", close);
process.once("SIGTERM", close);
await app.listen({
  host: process.env.HOST ?? "127.0.0.1",
  port: Number(process.env.PORT ?? 3001),
});
const selectedNames = (process.env.MONITOR_PROGRAMS ?? "")
  .split(",")
  .filter(Boolean);
if (selectedNames.length) {
  if (!process.env.SOLANA_WS_URL)
    throw Error("MONITOR_PROGRAMS requires SOLANA_WS_URL");
  const programs = selectedNames.map((name) => {
    const p = VERIFIED_PROGRAMS.find((p) => p.name === name);
    if (!p) throw Error(`Unverified program: ${name}`);
    return p;
  });
  await mkdir("data", { recursive: true });
  monitor = new SolanaMonitor(
    process.env.SOLANA_WS_URL,
    programs,
    (event) => {
      if (pendingObservations >= 100) {
        app.log.error("Observation backlog full; backfill required");
        return;
      }
      pendingObservations++;
      observationQueue = observationQueue
        .then(async () => {
          await appendFile(
            "data/observations.jsonl",
            JSON.stringify(event) + "\n",
            { mode: 0o600 },
          );
          await store.transaction((s) => {
            s.rpc.status = "receiving";
            s.metrics.latestSlot = Math.max(
              s.metrics.latestSlot ?? 0,
              event.slot,
            );
            s.metrics.observations = (s.metrics.observations ?? 0) + 1;
          });
          if (db)
            await db.query(
              "INSERT INTO events(id,kind,payload) VALUES($1,$2,$3) ON CONFLICT(id) DO NOTHING",
              [
                `${event.program}:${event.signature}`,
                "program-observation",
                event,
              ],
            );
          if (event.program === "pump" && !event.failed) {
            for (const launch of decodeLaunch(event)) {
              discoveries.unshift(launch);
              discoveries.splice(200);
              app.log.info(
                { mint: launch.mint, slot: launch.slot },
                "Pump launch decoded; enrichment required before paper strategy",
              );
            }
          }
        })
        .catch(() => {
          app.log.warn(
            "Observation persistence or decoding failed; inspect read-only CLI",
          );
        })
        .finally(() => {
          pendingObservations--;
        });
    },
    {
      onError: (error) => {
        app.log.warn({ message: error.message }, "Read-only monitor");
        void store
          .transaction((s) => {
            s.rpc.status = "degraded";
          })
          .catch(() => {});
      },
    },
  );
  await store.transaction((s) => {
    s.rpc.status = "connecting";
  });
  monitor.start();
}
