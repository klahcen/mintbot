import { telemetry, type Telemetry } from "./telemetry.js";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { StateSchema, type State, type Strategy } from "./model.js";
export function initial(strategy: Strategy, balanceSol = 10): State {
  return {
    version: 1,
    mode: "paper",
    running: false,
    killed: false,
    balanceSol,
    day: new Date().toISOString().slice(0, 10),
    dailySpendSol: 0,
    failures: 0,
    strategies: [strategy],
    launches: [],
    positions: [],
    trades: [],
    alerts: [],
    seen: [],
    pendingLaunches: [],
    metrics: {},
    rpc: { status: "not-configured" },
    realizedPnlSol: 0,
  };
}
export class Store {
  private tail: Promise<unknown> = Promise.resolve();
  constructor(
    public state: State,
    private path?: string,
    public readonly metrics: Telemetry = telemetry,
  ) {}
  async transaction<T>(fn: (s: State) => T | Promise<T>): Promise<T> {
    const enqueued = this.metrics.now();
    this.metrics.adjustGauge("store.queue_depth", 1);
    const end = this.metrics.start("store.transaction_ms");
    const op = this.tail.then(async () => {
      this.metrics.adjustGauge("store.queue_depth", -1);
      this.metrics.adjustGauge("store.in_flight", 1);
      this.metrics.observe(
        "store.queue_wait_ms",
        this.metrics.now() - enqueued,
      );
      try {
        const next = this.metrics.measure("store.clone_ms", () =>
          structuredClone(this.state),
        );
        const result = await fn(next);
        this.metrics.measure("store.validation_ms", () =>
          StateSchema.parse(next),
        );
        const path = this.path;
        if (path) {
          await this.metrics.measureAsync("store.persistence_ms", async () => {
            await mkdir(dirname(path), { recursive: true });
            await writeFile(path + ".tmp", JSON.stringify(next), {
              mode: 0o600,
            });
            await rename(path + ".tmp", path);
          });
        }
        this.state = next;
        this.metrics.increment("store.committed");
        return result;
      } catch (error) {
        this.metrics.increment("store.errors");
        throw error;
      } finally {
        this.metrics.adjustGauge("store.in_flight", -1);
        end();
      }
    });
    this.tail = op.catch(() => {});
    return op;
  }
}
export async function load(
  path: string,
  fallback: State,
  metrics: Telemetry = telemetry,
) {
  try {
    const s = StateSchema.parse(JSON.parse(await readFile(path, "utf8")));
    s.running = false;
    s.pendingLaunches = [];
    return new Store(s, path, metrics);
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === "ENOENT")
      return new Store(fallback, path, metrics);
    throw e;
  }
}
