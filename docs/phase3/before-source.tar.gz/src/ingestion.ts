import {
  EventJournal,
  InvalidObservationError,
  type WorkItem,
  type Anchor,
} from "./event-journal.js";
import { DecoderRegistry } from "./decoders.js";
import { BoundedStage } from "./stages.js";
import { telemetry, type Telemetry } from "./telemetry.js";
import type { ProgramObservation, PumpLaunch } from "./chain.js";
export interface IngestionOptions {
  journal: EventJournal;
  metrics?: Telemetry;
  capacity?: number;
  decodeConcurrency?: number;
  enrichmentConcurrency?: number;
  maxAttempts?: number;
  registry?: DecoderRegistry;
  enrich?: (
    observation: ProgramObservation,
    launches: PumpLaunch[],
  ) => Promise<unknown>;
  strategy?: (
    observation: ProgramObservation,
    launches: PumpLaunch[],
    identity: string,
    enrichment: unknown,
  ) => Promise<void> | void;
  persist?: (
    observation: ProgramObservation,
    launches: PumpLaunch[],
    identity: string,
  ) => Promise<void> | void;
  onCommitted?: (
    observation: ProgramObservation,
    launches: PumpLaunch[],
  ) => void;
}
/** Global in-flight bound; each stage has its own worker budget. Deferred work resides in a bounded WAL. */
export class EventIngestion {
  readonly metrics: Telemetry;
  readonly journal: EventJournal;
  readonly registry: DecoderRegistry;
  private readonly decode: BoundedStage;
  private readonly enrich: BoundedStage;
  private readonly strategy: BoundedStage;
  private readonly persist: BoundedStage;
  private readonly inFlight = new Set<string>();
  private readonly flows = new Map<string, Promise<void>>();
  private readonly received = new Map<string, number>();
  private readonly deferred = new Set<string>();
  private readonly resumed = new Set<string>();
  private scheduled = false;
  private timer: ReturnType<typeof setTimeout> | undefined;
  private accepting = true;
  private fatal: string | undefined;
  private readonly capacity: number;
  constructor(private options: IngestionOptions) {
    this.journal = options.journal;
    this.metrics = options.metrics ?? telemetry;
    this.registry = options.registry ?? new DecoderRegistry();
    this.capacity = options.capacity ?? 128;
    this.decode = new BoundedStage(
      "ingest.decode",
      this.capacity,
      options.decodeConcurrency ?? 1,
      this.metrics,
    );
    this.enrich = new BoundedStage(
      "ingest.enrichment",
      this.capacity,
      options.enrichmentConcurrency ?? Math.min(4, this.capacity),
      this.metrics,
    );
    this.strategy = new BoundedStage(
      "ingest.strategy",
      this.capacity,
      1,
      this.metrics,
    );
    this.persist = new BoundedStage(
      "ingest.persistence",
      this.capacity,
      1,
      this.metrics,
    );
    if (
      !Number.isInteger(options.maxAttempts ?? 3) ||
      (options.maxAttempts ?? 3) < 1 ||
      (options.maxAttempts ?? 3) > 10
    )
      throw Error("Invalid ingestion retry bound");
    for (const id of this.journal.pending.keys()) this.resumed.add(id);
    this.metrics.increment("ingest.resumed_from_wal", this.resumed.size);
    this.schedule();
  }
  accept(
    observation: ProgramObservation,
    origin: WorkItem["origin"] = "live",
  ): {
    status: "accepted" | "deferred" | "duplicate" | "unrecoverable";
    id?: string;
    reason?: string;
  } {
    this.metrics.increment("ingest.offered");
    if (!this.accepting || this.fatal) {
      this.metrics.increment("ingest.unrecoverable_offers");
      return { status: "unrecoverable" };
    }
    try {
      const result = this.metrics.measure("ingest.receipt_ms", () =>
        this.journal.offer(observation, origin),
      );
      if (result.status === "duplicate") {
        this.metrics.increment("ingest.duplicates");
        return { status: "duplicate", id: result.id };
      }
      if (result.status === "stale" || result.status === "full") {
        this.metrics.increment("ingest.unpersisted");
        this.recordGap(
          observation.program,
          Math.max(0, observation.slot - 32),
          observation.slot,
          result.status === "stale"
            ? "outside-dedupe-window"
            : "journal-capacity",
          this.journal.anchors.get(observation.program),
          1,
        );
        return {
          status: "unrecoverable",
          id: result.id,
          reason:
            result.status === "full"
              ? "journal-capacity"
              : "outside-dedupe-window",
        };
      }
      // The WAL owns payloads. This extra timing map is independently bounded to the WAL's pending bound.
      this.received.set(
        result.id,
        observation.receivedAtMonoMs ?? this.metrics.now(),
      );
      const deferred =
        this.inFlight.size >= this.capacity ||
        this.journal.pending.size > this.capacity;
      if (deferred) {
        this.deferred.add(result.id);
        this.metrics.increment("ingest.deferred");
      }
      this.schedule();
      return { status: deferred ? "deferred" : "accepted", id: result.id };
    } catch (error) {
      if (error instanceof InvalidObservationError) {
        this.metrics.increment("ingest.invalid_observations");
        this.metrics.increment("ingest.unrecoverable_offers");
        return { status: "unrecoverable" };
      }
      this.fatal = "journal-or-observation-failure";
      this.metrics.increment("ingest.unrecoverable_offers");
      return { status: "unrecoverable" };
    }
  }
  recordGap(
    program: string,
    fromSlot: number,
    toSlot: number,
    reason: string,
    anchor?: Anchor,
    refused = 0,
  ) {
    try {
      return this.journal.recordGap(
        program,
        fromSlot,
        toSlot,
        reason,
        arguments.length >= 5 ? anchor : this.journal.anchors.get(program),
        refused,
      );
    } catch {
      this.fatal = "gap-persistence-failed";
      this.metrics.increment("ingest.journal_errors");
      return undefined;
    }
  }
  private schedule() {
    if (this.scheduled || this.fatal) return;
    this.scheduled = true;
    setImmediate(() => {
      this.scheduled = false;
      this.pump();
    });
  }
  private pump() {
    if (this.fatal) return;
    let wake = Infinity;
    for (const item of this.journal.pending.values()) {
      if (this.inFlight.size >= this.capacity) break;
      if (item.quarantined || this.inFlight.has(item.id)) continue;
      if (item.notBefore > Date.now()) {
        wake = Math.min(wake, item.notBefore);
        continue;
      }
      this.inFlight.add(item.id);
      this.metrics.adjustGauge("ingest.in_flight", 1);
      const received = this.received.get(item.id) ?? this.metrics.now();
      const started = this.decode.trySubmit(
        () => this.registry.decode(item.observation, this.metrics),
        received,
      );
      if (!started) {
        this.inFlight.delete(item.id);
        this.metrics.adjustGauge("ingest.in_flight", -1);
        break;
      }
      const flow = started
        .then(async (decoded) => {
          if (!decoded.supported)
            this.metrics.increment("ingest.observation_only");
          const enrichment = this.enrich.trySubmit(
            () => this.options.enrich?.(item.observation, decoded.launches),
            received,
          );
          if (!enrichment) throw Error("Stage capacity invariant");
          const details = await enrichment;
          const decision = this.strategy.trySubmit(
            () =>
              this.options.strategy?.(
                item.observation,
                decoded.launches,
                item.id,
                details,
              ),
            received,
          );
          if (!decision) throw Error("Stage capacity invariant");
          await decision;
          const persisted = this.persist.trySubmit(async () => {
            await this.options.persist?.(
              item.observation,
              decoded.launches,
              item.id,
            );
            this.journal.complete(item.id);
          }, received);
          if (!persisted) throw Error("Stage capacity invariant");
          await persisted;
          this.metrics.increment("ingest.completed");
          if (this.resumed.delete(item.id))
            this.metrics.increment("ingest.restart_completed");
          if (item.origin === "history")
            this.metrics.increment("ingest.recovered");
          if (this.deferred.delete(item.id))
            this.metrics.increment("ingest.deferred_completed");
          this.metrics.observe(
            "ingest.end_to_end_ms",
            this.metrics.now() - received,
          );
          try {
            this.options.onCommitted?.(item.observation, decoded.launches);
          } catch {
            this.metrics.increment("ingest.dashboard_errors");
          }
        })
        .catch(() => {
          this.metrics.increment("ingest.processing_errors");
          try {
            this.journal.retry(
              item.id,
              this.options.maxAttempts ?? 3,
              Math.min(1000, 25 * 2 ** item.attempts),
            );
            if (item.quarantined) this.metrics.increment("ingest.quarantined");
          } catch {
            this.fatal = "retry-persistence-failed";
            this.metrics.increment("ingest.journal_errors");
          }
        })
        .finally(() => {
          this.inFlight.delete(item.id);
          this.flows.delete(item.id);
          this.metrics.adjustGauge("ingest.in_flight", -1);
          if (!this.journal.pending.has(item.id) || item.quarantined) {
            this.received.delete(item.id);
            this.deferred.delete(item.id);
          }
          this.schedule();
        });
      this.flows.set(item.id, flow);
    }
    if (wake < Infinity && !this.timer) {
      this.timer = setTimeout(
        () => {
          this.timer = undefined;
          this.schedule();
        },
        Math.max(1, wake - Date.now()),
      );
    }
  }
  async drain(timeoutMs = 60000) {
    const deadline = Date.now() + timeoutMs;
    while (
      !this.fatal &&
      (this.inFlight.size ||
        this.scheduled ||
        [...this.journal.pending.values()].some((w) => !w.quarantined))
    ) {
      if (Date.now() > deadline)
        throw Error(
          "Ingestion drain deadline exceeded; work remains journaled",
        );
      await new Promise((r) => setTimeout(r, 2));
    }
    if (this.fatal) throw Error(this.fatal);
  }
  status() {
    return {
      accepting: this.accepting,
      fatal: this.fatal ?? null,
      inFlight: this.inFlight.size,
      capacity: this.capacity,
      resumedPending: this.resumed.size,
      decodedCoverage: this.registry.coverage(),
      ...this.journal.status(),
    };
  }
  async close() {
    this.accepting = false;
    let failed: unknown;
    try {
      await this.drain();
    } catch (error) {
      failed = error;
    } finally {
      if (this.timer) clearTimeout(this.timer);
      await Promise.allSettled([...this.flows.values()]);
      for (const stage of [
        this.decode,
        this.enrich,
        this.strategy,
        this.persist,
      ]) {
        stage.close();
        await stage.drain();
      }
      this.journal.close();
    }
    if (failed) throw failed;
  }
}
