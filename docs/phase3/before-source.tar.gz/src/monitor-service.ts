import { appendFile, mkdir } from "node:fs/promises";
import { dirname } from "node:path";
import {
  SolanaMonitor,
  VERIFIED_PROGRAMS,
  type PumpLaunch,
  type ProgramObservation,
  type ProgramDefinition,
} from "./chain.js";
import { EventJournal, type JournalOptions } from "./event-journal.js";
import { EventIngestion } from "./ingestion.js";
import {
  HttpRecoveryRpc,
  RecoveryCoordinator,
  type BackfillOptions,
} from "./backfill.js";
import { BoundedStage } from "./stages.js";
import { telemetry, type Telemetry } from "./telemetry.js";
export interface MonitoringOptions {
  programs: readonly ProgramDefinition[];
  websocketUrls: string[];
  rpcUrl?: string;
  journal: JournalOptions;
  rawPath: string;
  metrics?: Telemetry;
  recovery?: BackfillOptions;
  onObservation?: (event: ProgramObservation) => void;
  discoveryPath?: string;
  onDiscovery?: (launch: PumpLaunch) => void;
  audit?: (event: ProgramObservation) => Promise<void>;
}
/** Runtime integration shared by HTTP server and standalone monitor. Never supplies prices or signs trades. */
export async function createMonitoringService(options: MonitoringOptions) {
  if (options.websocketUrls.length < 1 || options.websocketUrls.length > 2)
    throw Error("Configure one or two WebSocket providers");
  for (const p of options.programs)
    if (
      !VERIFIED_PROGRAMS.some(
        (v) => v.name === p.name && v.address === p.address,
      )
    )
      throw Error("Unverified runtime program");
  await mkdir(dirname(options.rawPath), { recursive: true });
  const metrics = options.metrics ?? telemetry;
  const journal = new EventJournal(options.journal);
  const startupAnchors = new Map(journal.anchors);
  let startupScheduled = false;
  const audit = new BoundedStage("ingest.audit", 64, 2, metrics);
  let receipts = 0,
    latestSlot = 0;
  const ready = options.websocketUrls.map(() => false);
  let closing = false;
  let pausedForBackpressure = false;
  const pipeline = new EventIngestion({
    journal,
    metrics,
    persist: async (event, launches) => {
      await appendFile(options.rawPath, JSON.stringify(event) + "\n", {
        mode: 0o600,
      });
      if (options.discoveryPath)
        for (const launch of launches)
          await appendFile(
            options.discoveryPath,
            JSON.stringify(launch) + "\n",
            { mode: 0o600 },
          );
    },
    onCommitted: (event, launches) => {
      for (const launch of launches) options.onDiscovery?.(launch);
      if (options.audit) {
        const result = audit.trySubmit(() => options.audit!(event));
        if (!result) metrics.increment("ingest.audit_deferred_unpersisted");
        else void result.catch(() => metrics.increment("ingest.audit_failed"));
      }
    },
  });
  const recovery = options.rpcUrl
    ? new RecoveryCoordinator(
        pipeline,
        new HttpRecoveryRpc(options.rpcUrl),
        options.recovery,
      )
    : undefined;
  const monitors = options.websocketUrls.map(
    (url, index) =>
      new SolanaMonitor(
        url,
        options.programs,
        (event) => {
          const result = pipeline.accept(event);
          if (result.reason === "journal-capacity") {
            pausedForBackpressure = true;
            for (const monitor of monitors) monitor.stop();
            metrics.increment("ingest.provider_pauses");
          }
          if (result.status === "accepted" || result.status === "deferred") {
            receipts++;
            latestSlot = Math.max(latestSlot, event.slot);
            try {
              options.onObservation?.(event);
            } catch {
              metrics.increment("ingest.observation_callback_errors");
            }
          }
        },
        {
          telemetry: metrics,
          deduplicate: false,
          onDisconnect: (context) => {
            ready[index] = false;
            if (closing) return;
            for (const program of options.programs) {
              const anchor = journal.anchors.get(program.name);
              pipeline.recordGap(
                program.name,
                Math.max(0, (anchor?.slot ?? context.latestSlot) - 32),
                Math.max(context.latestSlot, anchor?.slot ?? 0),
                "websocket-disconnect",
                anchor,
              );
            }
          },
          onReady: (context) => {
            ready[index] = true;
            if (closing) return;
            const initialRecovery = !startupScheduled;
            startupScheduled = true;
            for (const program of options.programs) {
              const gap = journal.gaps.get(program.name);
              const anchor =
                gap && gap.status !== "recovered"
                  ? gap.anchor
                  : context.reconnected
                    ? journal.anchors.get(program.name)
                    : initialRecovery
                      ? startupAnchors.get(program.name)
                      : undefined;
              if (anchor || gap) {
                if (recovery) recovery.request(program.name, anchor);
                else
                  pipeline.recordGap(
                    program.name,
                    gap?.fromSlot ?? Math.max(0, anchor!.slot - 32),
                    gap?.toSlot ?? anchor!.slot,
                    "rpc-not-configured",
                    anchor,
                  );
              }
            }
          },
          onError: () => metrics.increment("monitor.service_errors"),
        },
      ),
  );
  const timer = setInterval(() => {
    if (closing) return;
    if (
      pausedForBackpressure &&
      !pipeline.status().fatal &&
      journal.pending.size < journal.maxPending / 2
    ) {
      pausedForBackpressure = false;
      for (const monitor of monitors) monitor.start();
      metrics.increment("ingest.provider_resumes");
    }
    if (!recovery) return;
    for (const gap of journal.gaps.values())
      if (
        (gap.status === "pending" || gap.status === "partial") &&
        gap.attempts < 3
      )
        recovery.request(gap.program, gap.anchor);
  }, 1000);
  timer.unref();
  return {
    pipeline,
    start() {
      for (const monitor of monitors) monitor.start();
    },
    snapshot() {
      const state = pipeline.status();
      return {
        ...state,
        providers: ready.map((connected, i) => ({
          provider: i === 0 ? "primary" : "secondary",
          subscribed: connected,
        })),
        recoveryConfigured: !!recovery,
        pausedForBackpressure,
        receipts,
        latestSlot,
      };
    },
    health() {
      if (pipeline.status().fatal) return "degraded";
      if (pausedForBackpressure) return "backpressured";
      if (!ready.some(Boolean)) return "connecting";
      if ([...journal.gaps.values()].some((g) => g.status !== "recovered"))
        return "backfill-incomplete";
      return receipts ? "receiving" : "subscribed";
    },
    recover(program?: string) {
      if (!recovery) throw Error("Read-only recovery RPC not configured");
      for (const p of options.programs.filter(
        (p) => !program || p.name === program,
      )) {
        const gap = journal.gaps.get(p.name);
        if (gap) journal.updateGap({ ...gap, attempts: 0, status: "pending" });
        recovery.request(
          p.name,
          gap ? gap.anchor : journal.anchors.get(p.name),
        );
      }
    },
    async close() {
      closing = true;
      clearInterval(timer);
      for (const monitor of monitors) monitor.stop();
      await recovery?.close();
      try {
        await pipeline.close();
      } finally {
        audit.close();
        await audit.drain();
      }
    },
  };
}
