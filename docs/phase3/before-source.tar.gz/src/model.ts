import { z } from "zod";
const nonnegative = z.number().finite().nonnegative();
export const StrategySchema = z
  .object({
    name: z.string().min(1).max(80),
    kind: z.enum(["launch", "pool", "momentum", "delayed"]),
    enabled: z.boolean(),
    tradeSol: nonnegative.positive(),
    maxTradeSol: nonnegative.positive(),
    maxDailySpendSol: nonnegative.positive(),
    maxPositions: z.number().int().min(1).max(100),
    maxSlippageBps: z.number().int().min(0).max(2000),
    reserveSol: nonnegative,
    maxRiskScore: nonnegative.max(100),
    maxFailures: z.number().int().positive(),
    minLiquiditySol: nonnegative,
    minMarketCapSol: nonnegative,
    maxMarketCapSol: nonnegative,
    minVolumeSol: nonnegative,
    minMomentumBps: z.number().finite(),
    delayMs: nonnegative,
    maxPriceAgeMs: nonnegative.positive(),
    takeProfitBps: nonnegative.positive(),
    stopLossBps: nonnegative.positive().max(10000),
    trailingStopBps: nonnegative.max(10000),
    maxHoldMs: nonnegative.positive(),
    creatorAllowlist: z.array(z.string()),
    creatorBlocklist: z.array(z.string()),
  })
  .strict();
export type Strategy = z.infer<typeof StrategySchema>;
export interface Launch {
  id: string;
  mint: string;
  symbol: string;
  platform: string;
  kind: "launch" | "pool";
  creator: string;
  priceSol: number;
  priceAt: number;
  detectedAt: number;
  liquiditySol: number;
  marketCapSol: number;
  volumeSol: number;
  momentumBps: number;
  mintAuthority: boolean | null;
  freezeAuthority: boolean | null;
  restricted: boolean | null;
  topHolderPct: number | null;
  sellSimulation: boolean | null;
  source: "synthetic" | "verified";
  riskScore?: number;
  reasons?: string[];
}
export interface Position {
  id: string;
  mint: string;
  symbol: string;
  quantity: number;
  entryPriceSol: number;
  priceSol: number;
  priceAt: number;
  highPriceSol: number;
  costSol: number;
  openedAt: number;
  liquiditySol: number;
  initialLiquiditySol: number;
  source: string;
}
export interface Trade {
  id: string;
  positionId: string;
  symbol: string;
  side: "buy" | "sell";
  amountSol: number;
  quantity: number;
  feeSol: number;
  slippageSol: number;
  pnlSol: number;
  status: "paper-filled";
  at: number;
  reason: string;
  source: string;
}
export interface Alert {
  id: string;
  at: number;
  level: "info" | "warning" | "error";
  message: string;
}
export interface State {
  version: 1;
  mode: "paper";
  running: boolean;
  killed: boolean;
  balanceSol: number;
  day: string;
  dailySpendSol: number;
  failures: number;
  strategies: Strategy[];
  launches: Launch[];
  positions: Position[];
  trades: Trade[];
  alerts: Alert[];
  seen: string[];
  pendingLaunches: Launch[];
  metrics: Record<string, number>;
  rpc: {
    status: string;
  };
  realizedPnlSol: number;
}
const timestamp = z.number().finite().nonnegative();
export const LaunchSchema = z
  .object({
    id: z.string().min(1),
    mint: z.string().min(1),
    symbol: z.string().min(1),
    platform: z.string(),
    kind: z.enum(["launch", "pool"]),
    creator: z.string(),
    priceSol: nonnegative.positive(),
    priceAt: timestamp,
    detectedAt: timestamp,
    liquiditySol: nonnegative,
    marketCapSol: nonnegative,
    volumeSol: nonnegative,
    momentumBps: z.number().finite(),
    mintAuthority: z.boolean().nullable(),
    freezeAuthority: z.boolean().nullable(),
    restricted: z.boolean().nullable(),
    topHolderPct: nonnegative.max(100).nullable(),
    sellSimulation: z.boolean().nullable(),
    source: z.enum(["synthetic", "verified"]),
    riskScore: nonnegative.max(100).optional(),
    reasons: z.array(z.string()).optional(),
  })
  .strict();
export const PositionSchema = z
  .object({
    id: z.string(),
    mint: z.string(),
    symbol: z.string(),
    quantity: nonnegative.positive(),
    entryPriceSol: nonnegative.positive(),
    priceSol: nonnegative.positive(),
    priceAt: timestamp,
    highPriceSol: nonnegative.positive(),
    costSol: nonnegative,
    openedAt: timestamp,
    liquiditySol: nonnegative,
    initialLiquiditySol: nonnegative,
    source: z.string(),
  })
  .strict();
export const TradeSchema = z
  .object({
    id: z.string(),
    positionId: z.string(),
    symbol: z.string(),
    side: z.enum(["buy", "sell"]),
    amountSol: nonnegative,
    quantity: nonnegative,
    feeSol: nonnegative,
    slippageSol: nonnegative,
    pnlSol: z.number().finite(),
    status: z.literal("paper-filled"),
    at: timestamp,
    reason: z.string(),
    source: z.string(),
  })
  .strict();
export const AlertSchema = z.object({
  id: z.string(),
  at: timestamp,
  level: z.enum(["info", "warning", "error"]),
  message: z.string(),
});
/** Shared constraints for full validation and immutable-row cached validation. */
export function createStateSchema(
  rows: {
    launch?: z.ZodType<Launch>;
    trade?: z.ZodType<Trade>;
    alert?: z.ZodType<Alert>;
  } = {},
) {
  return z
    .object({
      version: z.literal(1),
      mode: z.literal("paper"),
      running: z.boolean(),
      killed: z.boolean(),
      balanceSol: nonnegative,
      day: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
      dailySpendSol: nonnegative,
      failures: z.number().int().nonnegative(),
      strategies: z.array(StrategySchema).length(1),
      launches: z.array(rows.launch ?? LaunchSchema).max(200),
      positions: z.array(PositionSchema).max(100),
      trades: z.array(rows.trade ?? TradeSchema).max(1000),
      alerts: z.array(rows.alert ?? AlertSchema).max(200),
      seen: z.array(z.string()).max(10000),
      pendingLaunches: z
        .array(rows.launch ?? LaunchSchema)
        .max(200)
        .default([]),
      metrics: z.record(z.string(), z.number().finite()),
      rpc: z.object({ status: z.string() }),
      realizedPnlSol: z.number().finite(),
    })
    .strict();
}
export const StateSchema = createStateSchema();
